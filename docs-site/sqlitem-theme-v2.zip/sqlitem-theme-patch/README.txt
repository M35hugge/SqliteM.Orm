Patch: Verbessertes Navbar-Layout & rechte "In this article"-Spalte

Installation:
1) Entpacke dieses Archiv ins Root deines DocFX-Projekts und überschreibe die vorhandene Datei:
   templates/sqlitem/styles/theme.css
2) DocFX neu bauen.

Änderungen:
- Navbar optisch verfeinert (Spacing, Typo, Suchfeld, Schatten)
- Rechte Seitenleiste ("In this article") als sticky, mit eigenem Stil
- Kleinere Kontrast- und Border-Anpassungen für Dark Theme